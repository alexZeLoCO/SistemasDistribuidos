#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cola.h"

// El contenido de este fichero implementa las funciones de la cola.
// Es prácticamente igual a la cola que tienes hecha de las prácticas
// de laboratorio pero adaptándola a la estructura de datos dato_cola
// usada en este ejercicio.
//
// Mira el fichero cola.h para ver las estructuras de datos a utilizar

void inicializar_cola(Cola *cola, int tam_cola)
{
    // A RELLENAR
    |
    |
    |
    |
}


void destruir_cola(Cola *cola)
{
    // A RELLENAR
    |
    |
    |
    |
}

void insertar_dato_cola(Cola *cola, dato_cola * dato)
{
    // A RELLENAR
    |
    |
    |
    |
}


dato_cola * obtener_dato_cola(Cola *cola)
{
    dato_cola *p;
    // A RELLENAR
    |
    |
    |
    |

    return(p);
}
